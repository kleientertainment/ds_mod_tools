Options = {
        "shadow_insanity1_basic" : [ "--skipantialias" ],
        "shadow_insanity2_basic" : [ "--skipantialias" ],
        "nightmarefuel" : [ "--skipantialias" ],
        "blocker_sanity_fx" : [ "--skipantialias" ],
}

