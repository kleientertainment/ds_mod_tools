from collections import namedtuple

Colour = namedtuple( "Colour", "r, g, b, a" )

