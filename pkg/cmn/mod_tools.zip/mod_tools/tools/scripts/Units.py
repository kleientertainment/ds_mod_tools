PixelsPerMeter = 150.0

