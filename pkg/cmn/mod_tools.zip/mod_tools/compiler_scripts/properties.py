ImageProperties = {
        "inventoryimages" : {
            "width" : 64,
            "height" : 64,
        },
        "road" : {
            "border" : 4,
        }
}
